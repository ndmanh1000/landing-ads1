export type featureData = {
  imgSrc: string
  heading: string
  paragraph: string
}