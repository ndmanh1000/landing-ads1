export type footerlLinksData = {
  label: string
  href: string
}
