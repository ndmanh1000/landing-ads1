export type socialLinksData = {
  imgSrc: string
  link: string
  width: number
}
